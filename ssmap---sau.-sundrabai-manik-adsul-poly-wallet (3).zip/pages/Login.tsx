
import React, { useState } from 'react';
import { UserRole, User } from '../types';
import { Wallet, ShieldCheck, User as UserIcon, GraduationCap } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Default emails if user leaves it blank for quick testing
    const defaultEmail = role === UserRole.STUDENT ? 'student.user@sau.edu.in' : 
                         role === UserRole.STAFF ? 'staff.member@sau.edu.in' : 
                         'admin.user@sau.edu.in';
    
    const finalEmail = email || defaultEmail;
    
    // Derive name from email prefix (e.g., "aman.sharma" -> "Aman Sharma")
    const prefix = finalEmail.split('@')[0];
    const derivedName = prefix
      .split(/[._-]/)
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');

    // In a real app, this would be an API call
    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: derivedName,
      role,
      balance: role === UserRole.ADMIN ? 0 : 2500,
      email: finalEmail,
      studentId: role === UserRole.STUDENT ? `2024${prefix.replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 4)}001` : undefined
    };
    onLogin(mockUser);
  };

  const roles = [
    { type: UserRole.STUDENT, icon: GraduationCap, label: 'Student' },
    { type: UserRole.STAFF, icon: UserIcon, label: 'Staff' },
    { type: UserRole.ADMIN, icon: ShieldCheck, label: 'Admin' }
  ];

  return (
    <div className="min-h-screen flex items-center justify-center bg-indigo-50 px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-indigo-600 text-white shadow-xl mb-6 transform hover:rotate-6 transition-transform">
            <Wallet className="w-12 h-12" />
          </div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">SSMAP</h1>
          <p className="mt-4 text-lg text-gray-600 font-medium">
            Welcome to Sau. Sundrabai Manik Adsul Poly Wallet
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-3 gap-3 mb-8">
              {roles.map((r) => (
                <button
                  key={r.type}
                  type="button"
                  onClick={() => setRole(r.type)}
                  className={`flex flex-col items-center justify-center p-3 rounded-2xl border-2 transition-all ${
                    role === r.type 
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700' 
                      : 'border-gray-100 hover:border-gray-200 text-gray-500'
                  }`}
                >
                  <r.icon className={`w-6 h-6 mb-1 ${role === r.type ? 'text-indigo-600' : 'text-gray-400'}`} />
                  <span className="text-xs font-bold uppercase tracking-wider">{r.label}</span>
                </button>
              ))}
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Campus Email</label>
              <input
                type="email"
                required
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all outline-none"
                placeholder="name.surname@sau.edu.in"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <p className="mt-1 text-[10px] text-gray-400">The name on your profile will be derived from this email.</p>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Password</label>
              <input
                type="password"
                required
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all outline-none"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all transform hover:scale-[1.02] active:scale-95"
            >
              Sign In to Wallet
            </button>
          </form>

          <div className="mt-8 text-center">
            <a href="#" className="text-sm font-bold text-indigo-600 hover:text-indigo-800 transition-colors">
              Forgot your wallet pin?
            </a>
          </div>
        </div>

        <p className="mt-8 text-center text-gray-500 text-sm">
          &copy; 2024 Sau. Sundrabai Manik Adsul Polytechnic. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default Login;
