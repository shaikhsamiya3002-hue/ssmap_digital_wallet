
import React from 'react';
import { User, Transaction, SpendData } from '../types';
import { 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight, 
  CreditCard, 
  ShoppingBag, 
  Book, 
  Coffee,
  School
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';

const MOCK_SPEND_DATA: SpendData[] = [
  { month: 'Jun', amount: 1200 },
  { month: 'Jul', amount: 2100 },
  { month: 'Aug', amount: 1500 },
  { month: 'Sep', amount: 2800 },
  { month: 'Oct', amount: 3200 },
  { month: 'Nov', amount: 2400 },
];

const RECENT_TRANSACTIONS: Transaction[] = [
  { id: '1', amount: 120, date: '2024-11-18', category: 'Canteen', description: 'Afternoon Lunch', type: 'debit' },
  { id: '2', amount: 50, date: '2024-11-17', category: 'Library', description: 'Overdue Fine', type: 'debit' },
  { id: '3', amount: 1500, date: '2024-11-15', category: 'Top-up', description: 'Wallet Refill', type: 'credit' },
  { id: '4', amount: 450, date: '2024-11-14', category: 'Stationery', description: 'Practical Journals', type: 'debit' },
];

const COLORS = ['#6366f1', '#a855f7', '#ec4899', '#f43f5e', '#f59e0b', '#10b981'];

const Dashboard: React.FC<{ user: User }> = ({ user }) => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-indigo-600 rounded-3xl p-8 text-white shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h2 className="text-lg font-medium opacity-90">Current Balance</h2>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-4xl md:text-5xl font-extrabold tracking-tight">₹{user.balance.toLocaleString()}</span>
              <span className="text-indigo-200 font-medium">INR</span>
            </div>
            <p className="mt-4 text-indigo-100 bg-indigo-500/30 inline-block px-3 py-1 rounded-lg text-sm">
              ID: {user.studentId || user.email}
            </p>
          </div>
          <div className="flex gap-4">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 flex-1 md:flex-none md:w-32 text-center">
              <p className="text-xs uppercase tracking-wider font-bold text-indigo-200">Income</p>
              <p className="text-xl font-bold mt-1">₹4,500</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 flex-1 md:flex-none md:w-32 text-center">
              <p className="text-xs uppercase tracking-wider font-bold text-indigo-200">Expense</p>
              <p className="text-xl font-bold mt-1">₹1,850</p>
            </div>
          </div>
        </div>
        {/* Background blobs for aesthetics */}
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-48 h-48 bg-indigo-400/20 rounded-full blur-3xl"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Analytics Section */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800">Monthly Spend Graph</h3>
              <div className="flex items-center gap-2 text-emerald-600 text-sm font-bold bg-emerald-50 px-2 py-1 rounded-lg">
                <TrendingUp className="w-4 h-4" />
                <span>+12.5%</span>
              </div>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={MOCK_SPEND_DATA}>
                  <defs>
                    <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="month" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 12}}
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 12}}
                  />
                  <Tooltip 
                    contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                    cursor={{stroke: '#6366f1', strokeWidth: 2}}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="amount" 
                    stroke="#6366f1" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorAmount)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Canteen', icon: Coffee, color: 'bg-orange-100 text-orange-600' },
              { label: 'Stationery', icon: ShoppingBag, color: 'bg-blue-100 text-blue-600' },
              { label: 'Library', icon: Book, color: 'bg-emerald-100 text-emerald-600' },
              { label: 'Fees', icon: School, color: 'bg-purple-100 text-purple-600' },
            ].map((cat) => (
              <div key={cat.label} className="bg-white p-4 rounded-2xl border border-gray-100 text-center hover:shadow-md transition-shadow cursor-pointer group">
                <div className={`w-12 h-12 ${cat.color} rounded-xl mx-auto flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                  <cat.icon className="w-6 h-6" />
                </div>
                <p className="text-sm font-bold text-gray-700">{cat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Transactions & Info */}
        <div className="space-y-8">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800">Recent Transactions</h3>
              <button className="text-sm font-bold text-indigo-600 hover:text-indigo-800">See All</button>
            </div>
            <div className="space-y-4">
              {RECENT_TRANSACTIONS.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between group cursor-pointer p-2 rounded-xl hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      tx.type === 'credit' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                    }`}>
                      {tx.type === 'credit' ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-900">{tx.description}</p>
                      <p className="text-xs text-gray-500 font-medium">{tx.category} • {tx.date}</p>
                    </div>
                  </div>
                  <p className={`text-sm font-bold ${
                    tx.type === 'credit' ? 'text-emerald-600' : 'text-gray-900'
                  }`}>
                    {tx.type === 'credit' ? '+' : '-'}₹{tx.amount}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-indigo-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
             <h4 className="text-lg font-bold mb-2">Campus Alert!</h4>
             <p className="text-indigo-200 text-sm leading-relaxed mb-4">
               Exam fees portal for Semester III is now open. Pay before Dec 5th to avoid late fines.
             </p>
             <button className="w-full bg-white text-indigo-900 font-bold py-3 rounded-xl hover:bg-indigo-50 transition-colors">
               Pay Exam Fees Now
             </button>
             <div className="absolute top-0 right-0 translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-indigo-500/20 rounded-full blur-2xl"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
