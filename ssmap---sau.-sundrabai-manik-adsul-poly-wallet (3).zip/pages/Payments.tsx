
import React, { useState } from 'react';
import { User, TransactionCategory } from '../types';
import { 
  Coffee, 
  ShoppingBag, 
  Book, 
  GraduationCap, 
  Building2, 
  ChevronRight,
  Wallet,
  CheckCircle2,
  AlertCircle,
  // Fix: Added missing CreditCard icon import
  CreditCard
} from 'lucide-react';

interface PaymentsProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
}

const Payments: React.FC<PaymentsProps> = ({ user, setUser }) => {
  const [selectedCategory, setSelectedCategory] = useState<TransactionCategory | null>(null);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const paymentOptions = [
    { id: 'Canteen', name: 'Campus Canteen', icon: Coffee, color: 'bg-orange-500', desc: 'Meals, snacks & drinks' },
    { id: 'Stationery', name: 'Stationery Store', icon: ShoppingBag, color: 'bg-blue-500', desc: 'Books, tools & materials' },
    { id: 'Library', name: 'Central Library', icon: Book, color: 'bg-emerald-500', desc: 'Overdue fines & memberships' },
    { id: 'Fees', name: 'Academic Fees', icon: GraduationCap, color: 'bg-purple-500', desc: 'Exam & Semester fees' },
    { id: 'Transfer', name: 'Hostel Fees', icon: Building2, color: 'bg-rose-500', desc: 'Accommodation & amenities' },
  ];

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCategory || !amount) return;
    
    setIsProcessing(true);
    setStatus('idle');

    // Simulate payment logic
    setTimeout(() => {
      const payAmount = parseFloat(amount);
      if (user.balance >= payAmount) {
        setUser(prev => prev ? { ...prev, balance: prev.balance - payAmount } : null);
        setStatus('success');
        setAmount('');
        setDescription('');
        setTimeout(() => setStatus('idle'), 3000);
      } else {
        setStatus('error');
      }
      setIsProcessing(false);
    }, 1500);
  };

  if (status === 'success') {
    return (
      <div className="flex flex-col items-center justify-center h-full max-w-lg mx-auto py-12 text-center animate-in zoom-in duration-300">
        <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-6">
          <CheckCircle2 className="w-16 h-16" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Payment Successful!</h2>
        <p className="text-gray-500 mb-8">Your transaction for {selectedCategory} has been processed successfully.</p>
        <button 
          onClick={() => { setStatus('idle'); setSelectedCategory(null); }}
          className="bg-indigo-600 text-white font-bold py-4 px-10 rounded-2xl shadow-lg hover:bg-indigo-700 transition-all"
        >
          Back to Payments
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Payment Selection */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-gray-800 ml-1">Choose Service</h3>
          <div className="space-y-3">
            {paymentOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => setSelectedCategory(opt.id as TransactionCategory)}
                className={`w-full flex items-center gap-4 p-4 rounded-3xl border-2 transition-all group ${
                  selectedCategory === opt.id 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-white bg-white hover:border-indigo-200 shadow-sm'
                }`}
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white ${opt.color} shadow-lg transition-transform group-hover:scale-110`}>
                  <opt.icon className="w-7 h-7" />
                </div>
                <div className="text-left flex-1">
                  <p className="font-bold text-gray-900">{opt.name}</p>
                  <p className="text-sm text-gray-500">{opt.desc}</p>
                </div>
                <ChevronRight className={`w-5 h-5 ${selectedCategory === opt.id ? 'text-indigo-600' : 'text-gray-300'}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Payment Form */}
        <div className="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 p-8 flex flex-col justify-between self-start sticky top-8">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="p-3 bg-indigo-100 text-indigo-600 rounded-2xl">
                <Wallet className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Make Payment</h3>
            </div>

            {!selectedCategory ? (
              <div className="text-center py-12 px-6">
                <div className="w-16 h-16 bg-gray-50 text-gray-300 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CreditCard className="w-8 h-8" />
                </div>
                <p className="text-gray-500 font-medium">Please select a campus service to start the payment</p>
              </div>
            ) : (
              <form onSubmit={handlePayment} className="space-y-6 animate-in slide-in-from-right-4 duration-300">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Paying To</label>
                  <div className="p-4 bg-gray-50 rounded-2xl font-bold text-indigo-700 border border-indigo-100">
                    {paymentOptions.find(o => o.id === selectedCategory)?.name}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Amount (₹)</label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-5 py-4 text-2xl font-bold rounded-2xl border border-gray-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all outline-none"
                    placeholder="0.00"
                  />
                  {status === 'error' && (
                    <div className="flex items-center gap-2 mt-2 text-rose-600 text-sm font-bold">
                      <AlertCircle className="w-4 h-4" />
                      <span>Insufficient wallet balance!</span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Optional Note</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all outline-none"
                    placeholder="What's this for?"
                    rows={2}
                  />
                </div>

                <button
                  type="submit"
                  disabled={isProcessing}
                  className={`w-full py-5 rounded-[2rem] font-bold text-lg shadow-xl transition-all transform flex items-center justify-center gap-3 ${
                    isProcessing 
                      ? 'bg-indigo-400 cursor-not-allowed' 
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white hover:scale-[1.02] active:scale-95'
                  }`}
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Processing...
                    </>
                  ) : (
                    <>Confirm Payment of ₹{amount || '0'}</>
                  )}
                </button>
              </form>
            )}
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-50 text-center">
            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Powered by SSMAP Secure</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payments;
