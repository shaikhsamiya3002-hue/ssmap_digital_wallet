
import React from 'react';
import { User } from '../types';
import { 
  Shield, 
  Mail, 
  IdCard, 
  Calendar, 
  MapPin, 
  Phone, 
  Building,
  CheckCircle,
  CreditCard,
  Wallet,
  BookOpen
} from 'lucide-react';

const Profile: React.FC<{ user: User }> = ({ user }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden text-center p-8">
            <div className="relative inline-block mb-6">
              <img
                src={`https://picsum.photos/seed/${user.email}/200/200`}
                alt="Profile Large"
                className="w-32 h-32 rounded-[2rem] border-4 border-indigo-50 shadow-inner"
              />
              <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white p-2 rounded-xl shadow-lg border-4 border-white">
                <CheckCircle className="w-5 h-5" />
              </div>
            </div>
            <h2 className="text-2xl font-extrabold text-gray-900 leading-tight">{user.name}</h2>
            <p className="text-indigo-600 font-bold uppercase tracking-widest text-xs mt-2 bg-indigo-50 inline-block px-3 py-1 rounded-full">
              {user.role}
            </p>
            
            <div className="mt-8 pt-8 border-t border-gray-50 space-y-4 text-left">
              <div className="flex items-center gap-3 text-gray-600">
                <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium truncate">{user.email}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center shrink-0">
                  <IdCard className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium">{user.studentId || "SSMAP-STAFF-ID"}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center shrink-0">
                  <Building className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium">Main Polytechnic Campus</span>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Info & Settings */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 p-8">
            <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-600" />
              Campus Identity Details
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Department</p>
                <p className="text-gray-900 font-semibold">Computer Engineering</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Batch</p>
                <p className="text-gray-900 font-semibold">2023 - 2026</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Phone Number</p>
                <p className="text-gray-900 font-semibold">+91 98765 43210</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Emergency Contact</p>
                <p className="text-gray-900 font-semibold">+91 91234 56789</p>
              </div>
            </div>
          </div>

          {/* MSBTE Project Info Block */}
          <div className="bg-emerald-50 rounded-[2.5rem] border-2 border-emerald-100 p-8">
             <h3 className="text-lg font-bold text-emerald-900 mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Capstone Project Information
            </h3>
            <div className="space-y-3 text-sm text-emerald-800">
              <p><strong>Project Name:</strong> Sau. Sundrabai Manik Adsul Poly Wallet (SSMAP)</p>
              <p><strong>Subject:</strong> Capstone Project (22060)</p>
              <p><strong>Tech Stack:</strong> React.js, TypeScript, Tailwind CSS, Lucide Icons</p>
              <p><strong>Academic Year:</strong> 2024-2025</p>
              <div className="mt-4 p-3 bg-emerald-100/50 rounded-xl text-xs leading-relaxed italic">
                This project fulfills the requirement for a digital campus ecosystem, automating canteen and fee management using modern client-side scripting.
              </div>
            </div>
          </div>

          {/* Wallet Summary in Profile */}
          <div className="bg-indigo-900 rounded-[2.5rem] shadow-xl p-8 text-white relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                <Wallet className="w-5 h-5 text-indigo-300" />
                Wallet Statistics
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 p-4 rounded-2xl border border-white/10">
                  <p className="text-indigo-200 text-xs font-bold uppercase mb-1">Total Spent (Nov)</p>
                  <p className="text-2xl font-bold">₹1,850</p>
                </div>
                <div className="bg-white/10 p-4 rounded-2xl border border-white/10">
                  <p className="text-indigo-200 text-xs font-bold uppercase mb-1">Wallet Status</p>
                  <p className="text-2xl font-bold flex items-center gap-2">
                    Active
                    <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
                  </p>
                </div>
              </div>
              <button className="w-full mt-6 py-4 bg-white text-indigo-900 font-bold rounded-2xl hover:bg-indigo-50 transition-all flex items-center justify-center gap-2">
                <CreditCard className="w-5 h-5" />
                Top-up Wallet Balance
              </button>
            </div>
            {/* Aesthetic Blobs */}
            <div className="absolute top-0 right-0 translate-x-1/4 -translate-y-1/4 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 -translate-x-1/4 translate-y-1/4 w-48 h-48 bg-indigo-400/20 rounded-full blur-2xl"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
