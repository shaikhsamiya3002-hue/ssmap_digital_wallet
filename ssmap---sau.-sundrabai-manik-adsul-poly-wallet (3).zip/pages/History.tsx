
import React, { useState } from 'react';
import { User, Transaction, TransactionCategory } from '../types';
import { 
  Search, 
  Filter, 
  Download, 
  Calendar,
  ChevronDown,
  ArrowUpRight,
  ArrowDownRight,
  FileText
} from 'lucide-react';

const ALL_TRANSACTIONS: Transaction[] = [
  { id: '1', amount: 120, date: '2024-11-18 12:45 PM', category: 'Canteen', description: 'Afternoon Lunch', type: 'debit' },
  { id: '2', amount: 50, date: '2024-11-17 04:30 PM', category: 'Library', description: 'Overdue Fine', type: 'debit' },
  { id: '3', amount: 1500, date: '2024-11-15 10:15 AM', category: 'Top-up', description: 'Wallet Refill', type: 'credit' },
  { id: '4', amount: 450, date: '2024-11-14 01:20 PM', category: 'Stationery', description: 'Practical Journals', type: 'debit' },
  { id: '5', amount: 2500, date: '2024-11-10 09:00 AM', category: 'Fees', description: 'Semester Exam Fees', type: 'debit' },
  { id: '6', amount: 65, date: '2024-11-08 11:15 AM', category: 'Canteen', description: 'Breakfast', type: 'debit' },
  { id: '7', amount: 200, date: '2024-11-05 02:40 PM', category: 'Top-up', description: 'Cash Deposit', type: 'credit' },
];

const History: React.FC<{ user: User }> = ({ user }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<TransactionCategory | 'All'>('All');
  const [isGenerating, setIsGenerating] = useState(false);

  const filteredTransactions = ALL_TRANSACTIONS.filter(tx => {
    const matchesSearch = tx.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         tx.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'All' || tx.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const generateReport = () => {
    setIsGenerating(true);
    // Simulate report generation delay
    setTimeout(() => {
      setIsGenerating(false);
      alert("SSMAP Project Report: Monthly transaction statement has been downloaded to your local storage.");
    }, 2000);
  };

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search transactions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-2xl shadow-sm focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all outline-none"
          />
        </div>
        <div className="flex gap-3">
          <div className="relative group">
            <select 
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value as any)}
              className="appearance-none pl-4 pr-10 py-3 bg-white border border-gray-200 rounded-2xl shadow-sm focus:ring-4 focus:ring-indigo-100 outline-none font-bold text-gray-700 cursor-pointer"
            >
              <option value="All">All Categories</option>
              <option value="Canteen">Canteen</option>
              <option value="Stationery">Stationery</option>
              <option value="Library">Library</option>
              <option value="Fees">Fees</option>
              <option value="Top-up">Top-up</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
          </div>
          <button 
            onClick={generateReport}
            disabled={isGenerating}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 border border-indigo-600 rounded-2xl shadow-lg hover:bg-indigo-700 transition-colors font-bold text-white disabled:opacity-50"
          >
            {isGenerating ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              <FileText className="w-4 h-4" />
            )}
            <span>{isGenerating ? 'Generating...' : 'Report'}</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50 border-b border-gray-100">
                <th className="px-8 py-5 text-xs font-bold text-gray-400 uppercase tracking-widest">Transaction</th>
                <th className="px-8 py-5 text-xs font-bold text-gray-400 uppercase tracking-widest">Category</th>
                <th className="px-8 py-5 text-xs font-bold text-gray-400 uppercase tracking-widest">Date & Time</th>
                <th className="px-8 py-5 text-xs font-bold text-gray-400 uppercase tracking-widest text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredTransactions.map((tx) => (
                <tr key={tx.id} className="group hover:bg-indigo-50/30 transition-colors cursor-pointer">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                        tx.type === 'credit' ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {tx.type === 'credit' ? <ArrowUpRight className="w-6 h-6" /> : <ArrowDownRight className="w-6 h-6" />}
                      </div>
                      <span className="font-bold text-gray-900 group-hover:text-indigo-700 transition-colors">{tx.description}</span>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="px-4 py-2 rounded-xl text-xs font-bold bg-gray-100 text-gray-600 group-hover:bg-white transition-colors">
                      {tx.category}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
                      <Calendar className="w-4 h-4" />
                      {tx.date}
                    </div>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <span className={`text-lg font-extrabold ${
                      tx.type === 'credit' ? 'text-emerald-600' : 'text-gray-900'
                    }`}>
                      {tx.type === 'credit' ? '+' : '-'}₹{tx.amount.toLocaleString()}
                    </span>
                  </td>
                </tr>
              ))}
              {filteredTransactions.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-16 h-16 bg-gray-50 text-gray-200 rounded-full flex items-center justify-center">
                        <Search className="w-8 h-8" />
                      </div>
                      <p className="text-gray-400 font-bold">No transactions found matching your criteria.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default History;
