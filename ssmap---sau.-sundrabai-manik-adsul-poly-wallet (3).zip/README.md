# 💳 SSMAP - Digital Campus Wallet

**The Unified Digital Payment Ecosystem for Sau. Sundrabai Manik Adsul Polytechnic.**

SSMAP is a high-performance, mobile-first digital wallet designed to modernize financial transactions within the campus. It provides students and staff with a secure, cashless environment to manage daily expenses and institutional payments.

---

## 🚀 Overview
SSMAP (Sau. Sundrabai Manik Adsul Poly Wallet) solves the inconvenience of cash handling in a busy campus environment. By integrating canteen, stationery, and fee modules into a single interface, it streamlines the campus experience for everyone.

### Core Objectives:
*   **Cashless Campus**: Eliminate the need for physical currency for micro-transactions.
*   **Transparency**: Provide students with real-time spending analytics.
*   **Efficiency**: Reduce queue times at payment counters through digital verification.

---

## ✨ Key Features

### 🏦 Smart Wallet Management
*   **Live Balance**: Instant visibility of available funds.
*   **Transaction Audit**: Detailed history with categorized debit/credit tracking.
*   **Quick Top-up**: Simple interface for refilling wallet balance.

### 💸 Specialized Payment Gateways
*   **Campus Canteen**: Digital ordering and meal payments.
*   **Stationery Shop**: Purchase journals, tools, and academic materials.
*   **Central Library**: Pay overdue fines and membership fees instantly.
*   **Administration**: Dedicated portal for Exam and Semester fee processing.

### 📊 Financial Insights
*   **Spending Analytics**: Interactive monthly graphs to track expenditure patterns.
*   **Expense Categorization**: Automatic tagging of transactions (Canteen, Fees, etc.).

### 🔐 Security & Access
*   **Role-Based Portals**: Customized dashboards for Students, Staff, and Administrators.
*   **Secure Auth**: Derived campus identity verification.
*   **PWA Ready**: Installable as a standalone app on any smartphone for native-like performance.

---

## 🛠️ Tech Stack

| Layer | Technology |
| :--- | :--- |
| **Frontend** | React 19 (Hooks, Functional Components) |
| **Language** | TypeScript (Type-safe architecture) |
| **Styling** | Tailwind CSS (Responsive Design) |
| **Visualization** | Recharts (SVG-based Analytics) |
| **Icons** | Lucide React |
| **Deployment** | Netlify |

---

## 📦 Project Structure
```text
├── components/       # Reusable UI components (Nav, Layout, Cards)
├── pages/            # View-level logic (Dashboard, Payments, History)
├── types.ts          # Centralized TypeScript definitions
├── App.tsx           # Route management and Auth state
├── index.html        # Entry point with ESM importmaps
└── manifest.json     # PWA configuration
```

---

## ⚙️ Installation & Development

### 1. Clone the repository
```bash
git clone https://github.com/your-username/ssmap-wallet.git
cd ssmap-wallet
```

### 2. Local Environment
Since the project uses **Native ESM Modules**, it can be run without a complex build step. Use any static file server:

**Using VS Code:**
Install the [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) extension and click "Go Live".

**Using Python:**
```bash
python -m http.server 8000
```

---

## 🌍 Deployment
This project is configured for seamless deployment on **Netlify**. It includes a `netlify.toml` file to handle Single Page Application (SPA) routing automatically.

---
*Maintained by the SSMAP Development Team.*