
export enum UserRole {
  STUDENT = 'STUDENT',
  STAFF = 'STAFF',
  ADMIN = 'ADMIN'
}

export type TransactionCategory = 'Canteen' | 'Stationery' | 'Fees' | 'Library' | 'Transfer' | 'Top-up';

export interface Transaction {
  id: string;
  amount: number;
  date: string;
  category: TransactionCategory;
  description: string;
  type: 'debit' | 'credit';
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  balance: number;
  email: string;
  studentId?: string;
}

export interface SpendData {
  month: string;
  amount: number;
}
